package cf.esp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Launcher screen of Astral: three steps, nothing else. */
public class MainActivity extends Activity {
    private static final int BG = 0xFF0E1013, CARD = 0xFF171A1F, EDGE = 0xFF262B32, ACCENT = 0xFF5AB0FF, TEXT = 0xFFE8EAED, DIM = 0xFF8B929B;

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int fill, int stroke, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView label(String t, float sp, int col, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(col);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private TextView button(String t, int fill, int textCol, View.OnClickListener l) {
        TextView b = label(t, 15, textCol, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(rounded(fill, fill == CARD ? EDGE : 0, 12));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    @Override
    protected void onCreate(Bundle st) {
        super.onCreate(st);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(BG);
        l.setPadding(dp(20), dp(44), dp(20), dp(20));

        TextView title = label("Astral", 34, TEXT, true);
        title.setLetterSpacing(0.04f);
        l.addView(title);
        l.addView(label("External overlay for Oxide: Survival Island  ·  root required", 13, DIM, false));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(CARD, EDGE, 14));
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(22);
        card.addView(label("How it works", 12, DIM, true));
        card.addView(label("1  Allow the overlay permission\n2  Start the game and join a match\n3  Press Start, then open the square W button on screen", 14, TEXT, false));
        l.addView(card, cp);

        l.addView(button("1   Allow overlay", CARD, TEXT, v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())))));
        l.addView(button("2   Start", ACCENT, 0xFF0B0D10, v -> {
            if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "Allow the overlay first (button 1)", Toast.LENGTH_LONG).show(); return; }
            Intent i = new Intent(this, EspService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "Started. The status line is bottom-left in the game.", Toast.LENGTH_LONG).show();
        }));
        l.addView(button("Stop", CARD, 0xFFFF6B5E, v -> stopService(new Intent(this, EspService.class))));

        TextView foot = label("Status line (bottom-left in game) tells you what was found: core ok, players, silent ready, movement objects.", 12, DIM, false);
        foot.setPadding(0, dp(18), 0, 0);
        l.addView(foot);
        setContentView(l);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
    }
}
